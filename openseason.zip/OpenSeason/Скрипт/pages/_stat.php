
<?PHP
$_OPTIMIZATION["title"] = "����������";
$_OPTIMIZATION["description"] = "����������";
$_OPTIMIZATION["keywords"] = "����������";
?>
<center><h3>���������� �������</h3></center>


<script type="text/javascript">
function openbox(id){
display = document.getElementById(id).style.display;
if(display=='none'){
document.getElementById(id).style.display='block';
}else{
document.getElementById(id).style.display='none';
}
}
</script>

<br><br>
<center>
<div class="question"><a href="#" style="text-decoration:none; background:#612a0b; color:#eecba1; border-radius:10px; padding:20px 20px 20px 20px;" onclick="openbox('q1'); return false"><b>��������� 10 ����������</b></a></div>
<div id="q1" style="display: none; padding:10px 0px 14px 10px;">
<br><br>
<table cellpadding="4" cellspacing="0" align="center" width="100%" class="table_info">
<tbody><tr align="center" class="ttb">
	<td><b>�����</b></td>
	<td><b>�����</b></td>
	<td><b>���� ����������</b></td>
</tr>
<?PHP	
$db->Query("SELECT * FROM db_insert_money, db_users_a  WHERE  db_users_a.user = db_insert_money.user ORDER BY db_insert_money.date_add DESC LIMIT 10 ");
	while($data2 = $db->FetchArray()){
?>
<tr align="center" class="ltb">
		<td><?=$data2["user"]; ?></td>
		<td><?=sprintf("%.2f",$data2["money"]); ?> ���.</td>
		<td><?=date("d.m.Y H:i",$data2["date_add"]); ?></td>
	</tr>
	<?PHP
	}
?>
</tbody></table>
</div>
</center>

<br><br><br>
<center>
<div class="question"><a href="#" style="text-decoration:none; background:#612a0b; color:#eecba1; border-radius:10px; padding:20px 44px 20px 44px;" onclick="openbox('q2'); return false"><b>��������� 10 ������</b></a></div>
<div id="q2" style="display: none; padding:10px 0px 14px 10px;">
<br><br>
<table cellpadding="4" cellspacing="0" align="center" width="100%" class="table_info">
<tbody><tr align="center" class="ttb">
	<td><b>�����</b></td>
	<td><b>�����</b></td>
	<td><b>���� �������</b></td>
</tr>
<?PHP

$all_pay_sum=0;
$dt = time() - 60*60*48;
$db->Query("SELECT * FROM db_payment, db_users_a  WHERE db_payment.status = '3' AND db_users_a.user = db_payment.user ORDER BY db_payment.date_add DESC LIMIT 10 ");
	while($data1 = $db->FetchArray()){
	
	$all_pay_sum += $data1["serebro"]/100;
		
	?>
<tr align="center" class="ltb">
		<td><?=$data1["user"]; ?></td>
		<td><?=sprintf("%.2f",$data1["sum"]); ?>  ���.</td>
		<td><?=date("d.m.Y H:i",$data1["date_add"]); ?></td>
	</tr>
	<?PHP
	}
?>
</tbody></table>
</div>
</center>


<br><br><br>
<center>
<div class="question"><a href="#" style="text-decoration:none; background:#612a0b; color:#eecba1; border-radius:10px; padding:20px 33px 20px 33px;" onclick="openbox('q3'); return false"><b>��������� �����������</b></a></div>
<div id="q3" style="display: none; padding:10px 0px 14px 10px;">
<br><br>
<table cellpadding="4" cellspacing="0" align="center" width="100%" class="table_info">
<tbody><tr align="center" class="ttb">
	<td><b>�����</b></td>
	<td><b>���������</b></td>
	<td><b>E-mail</b></td>
</tr>
	<?PHP
$db->Query("SELECT * FROM db_users_a ORDER BY date_reg DESC LIMIT 20 ");
	while($data = $db->FetchArray()){
?>
<tr align="center" class="ltb">
		<td><?=$data["user"]; ?></td>
		<td><?=$data["referer"]; ?></td>
		<td><?=str_replace(substr($data["email"],2,3), '<font color="red">***</font>', $data["email"]); ?></td>
	</tr>
	<?PHP
	}
?>
</tbody></table>
</div>
</center>



<br><br><br>
<center>
<div class="question"><a href="#" style="text-decoration:none; background:#612a0b; color:#eecba1; border-radius:10px; padding:20px 63px 20px 63px;" onclick="openbox('q4'); return false"><b>��� 10 ���������</b></a></div>
<div id="q4" style="display: none; padding:10px 0px 14px 10px;">
<br><br>
<table cellpadding="4" cellspacing="0" align="center" width="100%" class="table_info">
<tbody><tr align="center" class="ttb">
	<td><b>�����</b></td>
	<td><b>���-�� ���������</b></td>
	<td><b>E-mail</b></td>
</tr>


<?php
	$db->Query("SELECT * FROM `db_users_a` ORDER BY referals DESC LIMIT 10 ");
	while($data = $db->FetchArray()){
	?>
<tr align="center" class="ltb">
		<td><?=$data["user"]; ?></td>
		<td><?=$data["referals"]; ?> ���.</td>
		<td><?=str_replace(substr($data["email"],2,3), '<font color="red">***</font>', $data["email"]); ?></td>
	</tr>
	<?PHP
	}
?>
</tbody></table>
</div>
</center>



<br><br>


