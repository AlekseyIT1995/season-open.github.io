<?PHP
class config{

	public $HostDB = "localhost";
	public $UserDB = "root";
	public $PassDB = "";
	public $BaseDB = "sezon-ohoti";    
	
	public $SYSTEM_START_TIME = 1467371617;
	public $VAL = "RUB";
    public $VAL2 = "���.";
	
	# PAYEER ���������
	public $AccountNumber = 'P1004568227';
	public $apiId = '123';
	public $apiKey = '123';
	
	public $shopID = 123;
	public $secretW = "123";
	
}
?>
