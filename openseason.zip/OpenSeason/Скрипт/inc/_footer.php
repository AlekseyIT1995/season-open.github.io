</div>
</div>
<div class="content-end">
<center>
<b>�� ���������:</b>
<br>
<div class="space"></div>
<img src="/img/payeer.png" width="110">
<img src="/img/yandex.png" width="110">
<img src="/img/fk.png" width="110">
<img src="/img/visa.png" width="110">
<img src="/img/master.png" width="110">
</center>

</div>
</div>