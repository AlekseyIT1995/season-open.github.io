<div class="user-menu">

<center>
<div style="background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #c4ce52), color-stop(1, #7c870f));
	background:-moz-linear-gradient(top, #c4ce52 5%, #7c870f 100%);
	background:-webkit-linear-gradient(top, #c4ce52 5%, #7c870f 100%);
	background:-o-linear-gradient(top, #c4ce52 5%, #7c870f 100%);
	background:-ms-linear-gradient(top, #c4ce52 5%, #7c870f 100%);
	background:linear-gradient(to bottom, #c4ce52 5%, #7c870f 100%);
	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#c4ce52', endColorstr='#7c870f',GradientType=0); 
	float:left; 
	margin-left:8px; 
	padding:15px 0px 15px 0px; 
	font-size: 25px; 
	width:450px;
	color:#fff;
	text-shadow: #7c870f 1px 1px 0, #7c870f -1px -1px 0, 
                 #7c870f -1px 1px 0, #7c870f 1px -1px 0;">
�� �������: <b>{!BALANCE_B!}</b> ���.
</div>


<div style="background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #c4ce52), color-stop(1, #7c870f));
	background:-moz-linear-gradient(top, #c4ce52 5%, #7c870f 100%);
	background:-webkit-linear-gradient(top, #c4ce52 5%, #7c870f 100%);
	background:-o-linear-gradient(top, #c4ce52 5%, #7c870f 100%);
	background:-ms-linear-gradient(top, #c4ce52 5%, #7c870f 100%);
	background:linear-gradient(to bottom, #c4ce52 5%, #7c870f 100%);
	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#c4ce52', endColorstr='#7c870f',GradientType=0); 
	float:right; 
	margin-right:9px; 
	padding:15px 0px 15px 0px; 
	font-size: 25px; 
	width:450px;
	color:#fff;
	text-shadow: #7c870f 1px 1px 0, #7c870f -1px -1px 0, 
                 #7c870f -1px 1px 0, #7c870f 1px -1px 0;">
�� �������: <b>{!BALANCE_P!}</b> ���.
</div>

</center>

<div class="clr"></div>
<br>


<a href="/heroes"><b>�����</b></a>
<a href="/arena"><b>�����</b></a>
<a href="/bonus"><b>�����</b></a>
<a href="/insert"><b>���������</b></a>
<a href="/payment"><b>�������</b></a>
<a href="/exchange"><b>�����</b></a>
<a href="/settings"><b>���������</b></a>
<a href="/referrals"><b>��������</b></a>
</div>